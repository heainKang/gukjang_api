// This is a manifest file that'll be compiled into application.js
// 
// Rails 애플리케이션의 기본 JavaScript 파일
console.log("Application loaded");
